import React from "react";
import Counter from "./Counter";
import FetchPost from "./FetchPost";

function App() {
    return (
        <div>
            <Counter />
            <FetchPost />
        </div>
    );
}

export default App;
