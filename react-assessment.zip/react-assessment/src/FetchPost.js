import React, { useState, useEffect } from "react";

function FetchPost() {
    const [title, setTitle] = useState("");

    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/posts/1")
            .then((response) => response.json())
            .then((data) => setTitle(data.title));
    }, []);

    return <h1>{title}</h1>;
}

export default FetchPost;
